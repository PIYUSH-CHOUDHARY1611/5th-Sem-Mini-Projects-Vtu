<?php
$name=$_POST['name'];
$email=$_POST['email'];
$gender=$_POST['animal'];
$user=$_POST['user'];
$password=$_POST['password'];
echo 'Name: '.$name.'<br>';
echo 'Email: '.$email.'<br>';
echo 'Gender: '.$gender.'<br>';
echo 'Username: '.$user.'<br>';
echo 'Password: '.$password.'<br>';
?>