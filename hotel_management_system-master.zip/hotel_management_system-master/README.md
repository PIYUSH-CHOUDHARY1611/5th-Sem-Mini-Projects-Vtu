# hotel_management_system

MIS Project Based on Hotel Management System

## Demo
[Demo](https://hotel-mis.000webhostapp.com/)

[Demo Video](https://www.youtube.com/watch?v=7Yuss5rGVC4)

# Features
- Add and Delete the room
- See the status of all the room
- Room Booking
- Employee Management
- Employee Salary Management
- Employee History
- Complainent
